﻿using ExamWork.Pages;
using FinalWork.Data;
using FinalWork.Models;
using FinalWork.Services;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace FinalWork.Pages
{
    public partial class ShopPage : Page
    {
        private readonly ProductService _service;
        public ObservableCollection<ExamProduct> Products { get; set; }
        public ShopPage()
        {
            InitializeComponent();

            _service = new ProductService(new StoreContext());

            LoadProductsAsync();
            FillManufacturerComboBoxAsync();
        }

        private async void LoadProductsAsync()
        {
            try
            {
                //decimal? fromCost = null;
                //decimal? toCost = null;

                //if (!string.IsNullOrWhiteSpace(fromTextBox.Text) && decimal.TryParse(fromTextBox.Text, out decimal parsedFromCost))
                //    fromCost = parsedFromCost;

                //if (!string.IsNullOrWhiteSpace(toTextBox.Text) && decimal.TryParse(toTextBox.Text, out decimal parsedToCost))
                //    toCost = parsedToCost;

                productsListBox.ItemsSource = await _service.GetProductsAsync();

                //productsListBox.ItemsSource = await _service.GetProductsAsync(
                //    searchTextBox.Text, 
                //    sortComboBox.SelectedIndex,
                //    fromCost.GetValueOrDefault(),
                //    toCost,
                //    manufacturerComboBox.SelectedValue.ToString());
            }
            catch 
            {
                MessageBox.Show("Не удалось вывести продукты");
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            userFullnameLabel.Content = $"{App.Current.Resources["UserSurname"].ToString()} " +
                                        $"{App.Current.Resources["UserName"].ToString()} " +
                                        $"{App.Current.Resources["UserPatronymic"].ToString()}";
        }

        public async Task FillManufacturerComboBoxAsync()
        {
            //    var manufacturers = await _service.GetManufacturersAsync();

            //    if (manufacturers != null)
            //        foreach (var manufacturer in manufacturers)
            //            manufacturerComboBox.Items.Add(manufacturer);
        }

        private void AuthorizationButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            NavigationService.Navigate(new AuthorizationPage());
        }

        private void FilterButton_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (filterGrid.Visibility == System.Windows.Visibility.Collapsed)
                filterGrid.Visibility = System.Windows.Visibility.Visible;
            else
                filterGrid.Visibility = System.Windows.Visibility.Collapsed;
        }
    }
}
