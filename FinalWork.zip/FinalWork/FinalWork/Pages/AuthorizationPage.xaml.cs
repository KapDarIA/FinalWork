﻿using FinalWork;
using FinalWork.Models;
using FinalWork.Pages;
using FinalWork.Services;
using System.Windows;
using System.Windows.Controls;

namespace ExamWork.Pages
{
    public partial class AuthorizationPage : Page
    {

        private UserService _service = new();

        public AuthorizationPage()
        {
            InitializeComponent();

            loginTextBox.Text = "loginDEmgu2018";
            passwordBox.Password = "0gC3bk";
        }

        private async void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            if (await _service.IsUserExistAsync(loginTextBox.Text, passwordBox.Password))
            {
                ExamUser user = await _service.GetUserAsync(loginTextBox.Text, passwordBox.Password);
                AcceptUserData(user);

                NavigationService.Navigate(new ShopPage());
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ShopPage());
        }

        private void GuestButton_Click(object sender, RoutedEventArgs e)
        {
            ExamUser user = new();
            AcceptUserData(user);

            NavigationService.Navigate(new ShopPage());
        }
        private void AcceptUserData(ExamUser user)
        {
            App.Current.Resources["UserID"] = user.UserId;
            App.Current.Resources["RoleID"] = user.RoleId;
            App.Current.Resources["UserName"] = user.Name;
            App.Current.Resources["UserSurname"] = user.Surname;
            App.Current.Resources["UserPatronymic"] = user.Patronymic;
            App.Current.Resources["UserLogin"] = user.Login;
            App.Current.Resources["UserPassword"] = user.Password;
        }
    }
}
