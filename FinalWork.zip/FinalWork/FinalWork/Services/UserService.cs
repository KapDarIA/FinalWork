﻿using FinalWork.Data;
using FinalWork.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FinalWork.Services
{
    public class UserService
    {
        private readonly StoreContext _context = new();

        public async Task<bool> IsUserExistAsync(string login, string password)
            => (await _context.ExamUsers.SingleOrDefaultAsync(u => u.Login == login && u.Password == password) != null) ? true : false;

        public async Task<ExamUser> GetUserAsync(string login, string password)
            => await _context.ExamUsers.SingleAsync(u => u.Login == login && u.Password == password);

    }
}
