﻿using System;
using System.Collections.Generic;
using FinalWork.Models;
using Microsoft.EntityFrameworkCore;

namespace FinalWork.Data;

public partial class StoreContext : DbContext
{
    public StoreContext()
    {
    }

    public StoreContext(DbContextOptions<StoreContext> options)
        : base(options)
    {
    }

    public virtual DbSet<ExamOrder> ExamOrders { get; set; }

    public virtual DbSet<ExamOrderProduct> ExamOrderProducts { get; set; }

    public virtual DbSet<ExamPickupPoint> ExamPickupPoints { get; set; }

    public virtual DbSet<ExamProduct> ExamProducts { get; set; }

    public virtual DbSet<ExamRole> ExamRoles { get; set; }

    public virtual DbSet<ExamUser> ExamUsers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source = DESKTOP-MFUEFES\\SQLEXPRESS; Initial Catalog = Exam; User ID = 2103; Password = 2103; Trust Server Certificate=True");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<ExamOrder>(entity =>
        {
            entity.HasKey(e => e.OrderId).HasName("PK__ExamOrde__C3905BAFC7CC9AED");

            entity.ToTable("ExamOrder");

            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.Date).HasColumnType("datetime");
            entity.Property(e => e.DeliveryDate).HasColumnType("datetime");
            entity.Property(e => e.UserId).HasColumnName("UserID");

            entity.HasOne(d => d.PickupPointNavigation).WithMany(p => p.ExamOrders)
                .HasForeignKey(d => d.PickupPoint)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ExamOrder_ExamPickupPoint");

            entity.HasOne(d => d.User).WithMany(p => p.ExamOrders)
                .HasForeignKey(d => d.UserId)
                .HasConstraintName("FK_ExamOrder_ExamUser");
        });

        modelBuilder.Entity<ExamOrderProduct>(entity =>
        {
            entity.HasKey(e => new { e.OrderId, e.ProductArticleNumber }).HasName("PK__ExamOrde__817A266255BBC081");

            entity.ToTable("ExamOrderProduct");

            entity.Property(e => e.OrderId).HasColumnName("OrderID");
            entity.Property(e => e.ProductArticleNumber).HasMaxLength(100);

            entity.HasOne(d => d.Order).WithMany(p => p.ExamOrderProducts)
                .HasForeignKey(d => d.OrderId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ExamOrder__Order__403A8C7D");

            entity.HasOne(d => d.ProductArticleNumberNavigation).WithMany(p => p.ExamOrderProducts)
                .HasForeignKey(d => d.ProductArticleNumber)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__ExamOrder__Produ__412EB0B6");
        });

        modelBuilder.Entity<ExamPickupPoint>(entity =>
        {
            entity.HasKey(e => e.PickupPointId);

            entity.ToTable("ExamPickupPoint");

            entity.Property(e => e.PickupPointId).HasColumnName("PickupPointID");
        });

        modelBuilder.Entity<ExamProduct>(entity =>
        {
            entity.HasKey(e => e.ArticleNumber).HasName("PK__ExamProd__2EA7DCD5BF55BCD9");

            entity.ToTable("ExamProduct");

            entity.Property(e => e.ArticleNumber).HasMaxLength(100);
            entity.Property(e => e.Cost).HasColumnType("decimal(19, 4)");
        });

        modelBuilder.Entity<ExamRole>(entity =>
        {
            entity.HasKey(e => e.RoleId).HasName("PK__Role__8AFACE3ADA63D503");

            entity.ToTable("ExamRole");

            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.Name).HasMaxLength(100);
        });

        modelBuilder.Entity<ExamUser>(entity =>
        {
            entity.HasKey(e => e.UserId).HasName("PK__User__1788CCAC0D783859");

            entity.ToTable("ExamUser");

            entity.Property(e => e.UserId).HasColumnName("UserID");
            entity.Property(e => e.Name).HasMaxLength(100);
            entity.Property(e => e.Patronymic).HasMaxLength(100);
            entity.Property(e => e.RoleId).HasColumnName("RoleID");
            entity.Property(e => e.Surname).HasMaxLength(100);

            entity.HasOne(d => d.Role).WithMany(p => p.ExamUsers)
                .HasForeignKey(d => d.RoleId)
                .HasConstraintName("FK_ExamUser_ExamRole");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
