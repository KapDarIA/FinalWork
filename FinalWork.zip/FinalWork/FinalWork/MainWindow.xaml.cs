﻿using ExamWork.Pages;
using FinalWork.Pages;
using System.Windows;
using System.Windows.Navigation;

namespace FinalWork
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            MainFrame.Content = new ShopPage();
        }

        private void MainFrame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}