﻿using System;
using System.Collections.Generic;

namespace FinalWork.Models;

public partial class ExamPickupPoint
{
    public int PickupPointId { get; set; }

    public string City { get; set; } = null!;

    public string? Street { get; set; }

    public string? Building { get; set; }

    public virtual ICollection<ExamOrder> ExamOrders { get; set; } = new List<ExamOrder>();
}
