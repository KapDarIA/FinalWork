﻿using System;
using System.Collections.Generic;

namespace FinalWork.Models;

public partial class ExamRole
{
    public int RoleId { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<ExamUser> ExamUsers { get; set; } = new List<ExamUser>();
}
